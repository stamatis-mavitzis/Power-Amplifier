#include "main.h"

#include "protection.h"

#include "protection_config.h"

#include "protection_io.h"

#include "sensors.h"

#include <stdbool.h>

#include <stdint.h>

static SensorData sensors;

static uint8_t faults = FAULT_NONE;

static bool muted = false;

static bool startup_complete = false;

static uint32_t startup_time = 0;

static uint32_t sample_time = 0;

/* Signed DC estimates, one per channel. */
static float dc_left_filtered = 0.0f;
static float dc_right_filtered = 0.0f;

typedef struct {
    uint32_t normal_since;
    uint32_t severe_since;
    bool normal_active;
    bool severe_active;
} DCFaultTimers;

static DCFaultTimers dc_left_timers = {0};
static DCFaultTimers dc_right_timers = {0};

/* --------------------------------------------------------- */

static float AbsFloat(float value)

{

    return (value < 0.0f) ? -value : value;

}

/* ---------------------------------------------------------

 * Immediately disconnect and latch fault

 * --------------------------------------------------------- */

static void RaiseFault(uint8_t fault)

{

    faults |= fault;

    startup_complete = false;

    ProtectionIO_SpeakersOff();

}

/* ---------------------------------------------------------

 * DC persistence detector

 * --------------------------------------------------------- */

/* Filter signed voltage BEFORE taking its magnitude. The ADC readings
 * must be taken at a predictable interval for this coefficient to apply. */
static float DC_Filter(float voltage, float *state)
{
    *state += DC_FILTER_ALPHA * (voltage - *state);
    return *state;
}

static void DC_ResetTimers(DCFaultTimers *timers)
{
    timers->normal_active = false;
    timers->severe_active = false;
    timers->normal_since = 0U;
    timers->severe_since = 0U;
}

/* Normal and severe thresholds have INDEPENDENT persistence timers.
 * Returns true only after a filtered DC magnitude persists long enough. */
static bool DC_Fault(float filtered_voltage, DCFaultTimers *timers,
                     uint32_t now)
{
    const float magnitude = AbsFloat(filtered_voltage);
    bool normal_fault = false;
    bool severe_fault = false;

    if (magnitude >= DC_TRIP_VOLTAGE)
    {
        if (!timers->normal_active)
        {
            timers->normal_since = now;
            timers->normal_active = true;
        }
        normal_fault = (uint32_t)(now - timers->normal_since)
                       >= DC_TRIP_TIME_MS;
    }
    else
    {
        timers->normal_active = false;
    }

    if (magnitude >= DC_FAST_TRIP_VOLTAGE)
    {
        if (!timers->severe_active)
        {
            timers->severe_since = now;
            timers->severe_active = true;
        }
        severe_fault = (uint32_t)(now - timers->severe_since)
                       >= DC_FAST_TRIP_TIME_MS;
    }
    else
    {
        timers->severe_active = false;
    }

    return normal_fault || severe_fault;
}

/* ---------------------------------------------------------

 * Check temperature-related faults

 * --------------------------------------------------------- */

static void CheckTemperatureFaults(void)

{

    if (!Sensors_TempValid(sensors.temp1_adc))

        RaiseFault(FAULT_TEMP1_SENSOR);

    if (!Sensors_TempValid(sensors.temp2_adc))

        RaiseFault(FAULT_TEMP2_SENSOR);

    if (Sensors_OverTemperature(sensors.temp1_adc) ||

        Sensors_OverTemperature(sensors.temp2_adc))

    {

        RaiseFault(FAULT_OVERTEMP);

    }

}

/* ---------------------------------------------------------

 * Check DC-related faults

 *

 * IMPORTANT:

 * This is only called AFTER the startup delay. This prevents

 * the A2/A3 bias-network startup transient from being

 * interpreted as a real amplifier DC fault.

 * --------------------------------------------------------- */

static void CheckDCFaults(void)
{
    const uint32_t now = HAL_GetTick();

    if (DC_Fault(dc_left_filtered, &dc_left_timers, now) ||
        DC_Fault(dc_right_filtered, &dc_right_timers, now))
    {
        RaiseFault(FAULT_DC);
    }
}

/* ---------------------------------------------------------

 * Conditions for speaker connection

 * --------------------------------------------------------- */

static bool SystemSafe(void)

{

    if (!Sensors_TempValid(sensors.temp1_adc))

        return false;

    if (!Sensors_TempValid(sensors.temp2_adc))

        return false;

    if (Sensors_OverTemperature(sensors.temp1_adc))

        return false;

    if (Sensors_OverTemperature(sensors.temp2_adc))

        return false;

    if (AbsFloat(

            dc_left_filtered)

        > DC_SAFE_VOLTAGE)

    {

        return false;

    }

    if (AbsFloat(

            dc_right_filtered)

        > DC_SAFE_VOLTAGE)

    {

        return false;

    }

    return true;

}

/* ---------------------------------------------------------

 * Conditions required to reset fault

 * --------------------------------------------------------- */

static bool ResetSafe(void)

{

    /* Temperature sensors must be working */

    if (!Sensors_TempValid(sensors.temp1_adc))

        return false;

    if (!Sensors_TempValid(sensors.temp2_adc))

        return false;

    /*

     * If an overtemperature fault occurred,

     * require cooling below approximately 90 °C

     * before allowing reset.

     */

    if (faults & FAULT_OVERTEMP)

    {

        if (!Sensors_TempCoolForReset(sensors.temp1_adc))

            return false;

        if (!Sensors_TempCoolForReset(sensors.temp2_adc))

            return false;

    }

    else

    {

        /*

         * For other faults, temperature simply

         * needs to remain below the 100 °C trip point.

         */

        if (Sensors_OverTemperature(sensors.temp1_adc))

            return false;

        if (Sensors_OverTemperature(sensors.temp2_adc))

            return false;

    }

    /* DC must be safely close to zero */

    if (AbsFloat(

            dc_left_filtered)

        > DC_SAFE_VOLTAGE)

    {

        return false;

    }

    if (AbsFloat(

            dc_right_filtered)

        > DC_SAFE_VOLTAGE)

    {

        return false;

    }

    return true;

}

/* --------------------------------------------------------- */

static void RestartStartup(void)

{

    ProtectionIO_SpeakersOff();

    startup_complete = false;

    startup_time = HAL_GetTick();

    /*

     * Clear DC persistence timers whenever a new

     * startup sequence begins.

     */

    DC_ResetTimers(&dc_left_timers);

    DC_ResetTimers(&dc_right_timers);

}

/* ---------------------------------------------------------

 * Decide whether speakers should be connected

 * --------------------------------------------------------- */

static void UpdateSpeakers(void)

{

    if ((faults != FAULT_NONE) ||

        muted ||

        !startup_complete)

    {

        ProtectionIO_SpeakersOff();

    }

    else

    {

        ProtectionIO_SpeakersOn();

    }

}

/* =========================================================

 * PUBLIC FUNCTIONS

 * ========================================================= */

void Protection_Init(void)

{

    ProtectionIO_Init();

    Sensors_Init();

    faults = FAULT_NONE;

    muted = false;

    sample_time = 0U;

    dc_left_filtered = 0.0f;
    dc_right_filtered = 0.0f;
    RestartStartup();

    ProtectionIO_UpdateLEDs(

        faults,

        true

    );

}

/* ========================================================= */

void Protection_Task(void)

{

    uint32_t now = HAL_GetTick();

    /* ---------------------------------

     * MUTE / ENABLE BUTTON

     * --------------------------------- */

    if (ProtectionIO_MutePressed())

    {

        muted = !muted;

        UpdateSpeakers();

    }

    /* ---------------------------------

     * FAULT RESET BUTTON

     * --------------------------------- */

    if (ProtectionIO_ResetPressed())

    {

        if ((faults != FAULT_NONE) &&

            ResetSafe())

        {

            faults = FAULT_NONE;

            RestartStartup();

        }

    }

    /* ---------------------------------

     * SENSOR UPDATE

     * --------------------------------- */

    if ((now - sample_time)

        < SAMPLE_INTERVAL_MS)

    {

        return;

    }

    sample_time = now;

    /*

     * ADC failure = fail safe.

     */

    if (!Sensors_Read(&sensors))

    {

        RaiseFault(

            FAULT_TEMP1_SENSOR |

            FAULT_TEMP2_SENSOR |

            FAULT_DC

        );

    }

    else

    {

        /*

         * Temperature protection is active immediately.

         */

        CheckTemperatureFaults();

        /* Always advance both DC estimators, including during startup,
         * mute and latched-fault states. Never rectify before filtering. */
        dc_left_filtered = DC_Filter(
            Sensors_DCVoltage(sensors.dc_left_adc), &dc_left_filtered);
        dc_right_filtered = DC_Filter(
            Sensors_DCVoltage(sensors.dc_right_adc), &dc_right_filtered);

        /*

         * DC protection is intentionally disabled during

         * the startup delay.

         *

         * A2 and A3 need time to settle to their normal

         * approximately 1.6 V zero-DC bias level.

         *

         * The speaker relays remain OFF during this entire

         * period, so the speakers remain protected.

         */

        if ((now - startup_time) >= STARTUP_DELAY_MS)

        {

            CheckDCFaults();

        }

        else

        {

            /*

             * Make absolutely sure no DC persistence time

             * is accumulated during startup.

             */

            DC_ResetTimers(&dc_left_timers);

            DC_ResetTimers(&dc_right_timers);

        }

    }

    /* ---------------------------------

     * 3 SECOND STARTUP DELAY

     * --------------------------------- */

    if (!startup_complete &&

        faults == FAULT_NONE)

    {

        if ((now - startup_time)

            >= STARTUP_DELAY_MS)

        {

            /*

             * Do not connect the speakers merely because

             * the three seconds have elapsed.

             *

             * A2/A3, temperature sensors and all other

             * safety conditions must also be valid.

             */

            if (SystemSafe())

            {

                startup_complete = true;

            }

        }

    }

    /* ---------------------------------

     * RELAYS

     * --------------------------------- */

    UpdateSpeakers();

    /* ---------------------------------

     * LEDs

     * --------------------------------- */

    ProtectionIO_UpdateLEDs(

        faults,

        (!startup_complete &&

         faults == FAULT_NONE)

    );

}
