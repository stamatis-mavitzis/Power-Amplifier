#include "sensors.h"
#include "protection_config.h"
#include "protection_pins.h"
#include "main.h"

#include <math.h>
#include <stddef.h>


extern ADC_HandleTypeDef hadc1;


/* =========================================================
 * READ ONE ADC CHANNEL
 * ========================================================= */

static bool ADC_ReadChannel(uint32_t channel, uint16_t *value)
{
    ADC_ChannelConfTypeDef config = {0};

    /*
     * ADC is configured in main.c as:
     *
     * hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
     * hadc1.Init.NbrOfConversion = 1;
     *
     * On the STM32G0 this means that the regular ADC
     * sequencer is fully configurable and contains one rank.
     *
     * Therefore every channel that we want to measure is
     * temporarily placed into REGULAR RANK 1.
     */
    config.Channel = channel;
    config.Rank = ADC_REGULAR_RANK_1;
    config.SamplingTime = ADC_SAMPLINGTIME_COMMON_1;


    if (HAL_ADC_ConfigChannel(&hadc1, &config) != HAL_OK)
    {
        return false;
    }


    if (HAL_ADC_Start(&hadc1) != HAL_OK)
    {
        return false;
    }


    if (HAL_ADC_PollForConversion(&hadc1, 10) != HAL_OK)
    {
        HAL_ADC_Stop(&hadc1);

        return false;
    }


    *value = (uint16_t)HAL_ADC_GetValue(&hadc1);


    HAL_ADC_Stop(&hadc1);


    return true;
}


/* =========================================================
 * AVERAGE SEVERAL ADC MEASUREMENTS
 * ========================================================= */

static bool ADC_ReadAverage(uint32_t channel, uint16_t *value)
{
    uint32_t sum = 0U;

    uint16_t sample = 0U;


    for (uint8_t i = 0U;
         i < ADC_AVERAGE_SAMPLES;
         i++)
    {
        if (!ADC_ReadChannel(channel, &sample))
        {
            return false;
        }


        sum += sample;
    }


    *value =
        (uint16_t)(sum / ADC_AVERAGE_SAMPLES);


    return true;
}


/* =========================================================
 * INITIALISE SENSOR SYSTEM
 * ========================================================= */

void Sensors_Init(void)
{
    /*
     * Calibrate the STM32 ADC once after MX_ADC1_Init().
     */
    HAL_ADCEx_Calibration_Start(&hadc1);
}


/* =========================================================
 * READ ALL SENSORS
 * ========================================================= */

bool Sensors_Read(SensorData *data)
{
    if (data == NULL)
    {
        return false;
    }


    /*
     * Temperature sensor 1
     *
     * PA0 / ADC channel 0
     */
    if (!ADC_ReadAverage(
            TEMP1_ADC_CHANNEL,
            &data->temp1_adc))
    {
        return false;
    }


    /*
     * Temperature sensor 2
     *
     * PA1 / ADC channel 1
     */
    if (!ADC_ReadAverage(
            TEMP2_ADC_CHANNEL,
            &data->temp2_adc))
    {
        return false;
    }


    /*
     * Left-channel DC sensor
     *
     * PA4 / ADC channel 4
     */
    if (!ADC_ReadAverage(
            DC_LEFT_ADC_CHANNEL,
            &data->dc_left_adc))
    {
        return false;
    }


    /*
     * Right-channel DC sensor
     *
     * PA5 / ADC channel 5
     */
    if (!ADC_ReadAverage(
            DC_RIGHT_ADC_CHANNEL,
            &data->dc_right_adc))
    {
        return false;
    }


    return true;
}


/* =========================================================
 * CHECK TEMPERATURE SENSOR VALIDITY
 * ========================================================= */

bool Sensors_TempValid(uint16_t adc)
{
    /*
     * Very low ADC:
     * possible short circuit.
     *
     * Very high ADC:
     * possible disconnected / open thermistor.
     */
    return (
        adc > TEMP_SHORT_ADC &&
        adc < TEMP_OPEN_ADC
    );
}


/* =========================================================
 * CONVERT THERMISTOR ADC READING TO DEGREES CELSIUS
 * ========================================================= */

float Sensors_TemperatureC(uint16_t adc)
{
    float resistance;

    float inverse_temperature;

    float temperature_kelvin;

    float temperature_celsius;


    /*
     * Protect against division by zero.
     *
     * Normally this should never be needed because
     * Sensors_TempValid() rejects extreme ADC readings.
     */
    if (adc == 0U)
    {
        adc = 1U;
    }


    if (adc >= 4095U)
    {
        adc = 4094U;
    }


    /*
     * Voltage divider:
     *
     *
     *       3.3 V
     *         |
     *      10 kOhm
     *      pull-up
     *         |
     *         +-------- ADC
     *         |
     *        NTC
     *         |
     *        GND
     *
     *
     * The NTC resistance is:
     *
     *             ADC
     * Rntc = Rpullup * ----------
     *                    ADCmax-ADC
     */
    resistance =
        NTC_PULLUP_RESISTANCE_OHM *
        (
            (float)adc /
            (
                ADC_MAX_COUNT -
                (float)adc
            )
        );


    /*
     * Convert resistance to absolute temperature
     * using the NTC Beta equation:
     *
     *
     * 1       1        ln(R / R0)
     * -   =   --   +   ----------
     * T       T0           Beta
     *
     *
     * where:
     *
     * T    = thermistor temperature in Kelvin
     *
     * T0   = nominal temperature in Kelvin
     *        normally 25 C = 298.15 K
     *
     * R    = measured thermistor resistance
     *
     * R0   = thermistor resistance at 25 C
     *
     * Beta = thermistor Beta constant
     */
    inverse_temperature =
        (
            1.0f /
            (
                NTC_NOMINAL_TEMP_C +
                273.15f
            )
        )
        +
        (
            logf(
                resistance /
                NTC_NOMINAL_RESISTANCE_OHM
            )
            /
            NTC_BETA_K
        );


    /*
     * Convert inverse temperature back to Kelvin.
     */
    temperature_kelvin =
        1.0f / inverse_temperature;


    /*
     * Convert Kelvin to Celsius.
     */
    temperature_celsius =
        temperature_kelvin - 273.15f;


    return temperature_celsius;
}


/* =========================================================
 * OVERTEMPERATURE DETECTION
 * ========================================================= */

bool Sensors_OverTemperature(uint16_t adc)
{
    /*
     * Invalid thermistor readings are handled separately
     * as sensor faults.
     */
    if (!Sensors_TempValid(adc))
    {
        return false;
    }


    /*
     * Convert the raw ADC reading into degrees Celsius.
     *
     * Trip when:
     *
     * temperature >= TEMP_TRIP_C
     */
    return (
        Sensors_TemperatureC(adc)
        >= TEMP_TRIP_C
    );
}


/* =========================================================
 * TEMPERATURE RESET HYSTERESIS
 * ========================================================= */

bool Sensors_TempCoolForReset(uint16_t adc)
{
    /*
     * Sensor must first be valid.
     */
    if (!Sensors_TempValid(adc))
    {
        return false;
    }


    /*
     * Allow reset only after the amplifier has cooled
     * to TEMP_RESET_C or below.
     */
    return (
        Sensors_TemperatureC(adc)
        <= TEMP_RESET_C
    );
}


/* =========================================================
 * CONVERT DC-SENSE ADC READING TO AMPLIFIER OUTPUT VOLTAGE
 * ========================================================= */

float Sensors_DCVoltage(uint16_t adc)
{
    return (
        ((float)adc - DC_CENTER_ADC)
        /
        DC_COUNTS_PER_VOLT
    );
}
