#ifndef PROTECTION_CONFIG_H
#define PROTECTION_CONFIG_H


/* =========================================================
 * TIMING
 * ========================================================= */

/* Wait before speakers may be connected */
#define STARTUP_DELAY_MS          3000U

/* Protection system sampling interval */
#define SAMPLE_INTERVAL_MS         10U

/* Pushbutton debounce */
#define BUTTON_DEBOUNCE_MS         30U

/* ADC samples averaged for each measurement */
#define ADC_AVERAGE_SAMPLES         8U


/* =========================================================
 * TEMPERATURE PROTECTION
 *
 * 10 kOhm NTC + 10 kOhm pull-up
 *
 * Circuit:
 *
 *      3.3 V
 *        |
 *      10 kOhm
 *      pull-up
 *        |
 *        +------ ADC
 *        |
 *       NTC
 *        |
 *       GND
 *
 * As temperature increases, NTC resistance decreases,
 * therefore the ADC reading also decreases.
 * ========================================================= */


/*
 * Temperature at which the speakers are disconnected.
 *
 * Example:
 * 100.0f = disconnect at approximately 100 degrees Celsius.
 */
#define TEMP_TRIP_C                  100.0f


/*
 * Temperature below which an overtemperature fault
 * may be reset.
 *
 * This creates hysteresis so that the relay does not
 * repeatedly switch ON and OFF around the trip temperature.
 */
#define TEMP_RESET_C                  90.0f


/*
 * NTC thermistor parameters.
 *
 * The values below reproduce the behaviour of the
 * previous ADC thresholds:
 *
 * 261 ADC counts ~= 100 C
 * 342 ADC counts ~= 90 C
 */
#define NTC_NOMINAL_RESISTANCE_OHM  10000.0f
#define NTC_NOMINAL_TEMP_C             25.0f
#define NTC_BETA_K                    3988.0f


/* Fixed pull-up resistor */
#define NTC_PULLUP_RESISTANCE_OHM   10000.0f


/*
 * STM32 ADC maximum value.
 *
 * 12-bit ADC:
 * 0 ... 4095
 */
#define ADC_MAX_COUNT                4095.0f


/*
 * Temperature sensor failure limits.
 *
 * Values very close to 0 indicate a possible short circuit.
 * Values very close to 4095 indicate a possible open circuit.
 */
#define TEMP_SHORT_ADC                 25U
#define TEMP_OPEN_ADC                4070U


/* =========================================================
 * DC OFFSET PROTECTION
 * ========================================================= */

/* ADC value corresponding approximately to 0 V amplifier DC */
#define DC_CENTER_ADC               1982.0f

/* ADC counts per volt at amplifier output */
#define DC_COUNTS_PER_VOLT            40.04f


/* Normal DC fault */
#define DC_TRIP_VOLTAGE                1.0f
#define DC_TRIP_TIME_MS              100U


/* Severe DC fault */
#define DC_FAST_TRIP_VOLTAGE           5.0f
#define DC_FAST_TRIP_TIME_MS          10U


/* Maximum DC offset allowed before reconnecting speakers */
#define DC_SAFE_VOLTAGE                0.5f


#endif /* PROTECTION_CONFIG_H */
