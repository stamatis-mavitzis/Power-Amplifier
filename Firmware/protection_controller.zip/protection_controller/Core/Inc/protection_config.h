#ifndef PROTECTION_CONFIG_H
#define PROTECTION_CONFIG_H

/* Timing */
#define STARTUP_DELAY_MS                 8000U
#define SAMPLE_INTERVAL_MS                10U
#define BUTTON_DEBOUNCE_MS                30U
#define ADC_AVERAGE_SAMPLES                8U

/* Temperature protection: existing values unchanged */
#define TEMP_TRIP_C                       100.0f
#define TEMP_RESET_C                       90.0f
#define NTC_NOMINAL_RESISTANCE_OHM     10000.0f
#define NTC_NOMINAL_TEMP_C                 25.0f
#define NTC_BETA_K                       3988.0f
#define NTC_PULLUP_RESISTANCE_OHM      10000.0f
#define ADC_MAX_COUNT                   4095.0f
#define TEMP_SHORT_ADC                    25U
#define TEMP_OPEN_ADC                   1900U

/* DC sense calibration; unchanged */
#define DC_CENTER_ADC                   1982.0f
#define DC_COUNTS_PER_VOLT                40.04f

/* Signed low-pass filter: at a 10ms interval alpha=0.05
 * yields an approximate 195ms time constant. */
#define DC_FILTER_ALPHA                    0.05f

/* Threshold comparisons apply to FILTERED DC, not instantaneous audio */
#define DC_TRIP_VOLTAGE                    1.0f
#define DC_TRIP_TIME_MS                   100U
#define DC_FAST_TRIP_VOLTAGE               5.0f
#define DC_FAST_TRIP_TIME_MS              100U
#define DC_SAFE_VOLTAGE                    0.5f

#endif /* PROTECTION_CONFIG_H */
