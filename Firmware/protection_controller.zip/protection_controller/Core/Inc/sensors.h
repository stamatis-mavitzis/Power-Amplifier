#ifndef SENSORS_H
#define SENSORS_H


#include <stdint.h>
#include <stdbool.h>


/* =========================================================
 * SENSOR DATA
 * ========================================================= */

typedef struct
{
    uint16_t temp1_adc;
    uint16_t temp2_adc;

    uint16_t dc_left_adc;
    uint16_t dc_right_adc;

} SensorData;


/* =========================================================
 * INITIALISATION / READING
 * ========================================================= */

void Sensors_Init(void);

bool Sensors_Read(SensorData *data);


/* =========================================================
 * TEMPERATURE FUNCTIONS
 * ========================================================= */

/*
 * Check whether the thermistor ADC reading looks valid.
 */
bool Sensors_TempValid(uint16_t adc);


/*
 * Convert thermistor ADC reading to degrees Celsius.
 */
float Sensors_TemperatureC(uint16_t adc);


/*
 * Returns true if temperature has reached or exceeded
 * TEMP_TRIP_C.
 */
bool Sensors_OverTemperature(uint16_t adc);


/*
 * Returns true when the temperature has cooled to or below
 * TEMP_RESET_C.
 */
bool Sensors_TempCoolForReset(uint16_t adc);


/* =========================================================
 * DC OFFSET
 * ========================================================= */

/*
 * Convert DC-sense ADC reading to amplifier output voltage.
 */
float Sensors_DCVoltage(uint16_t adc);


#endif /* SENSORS_H */
